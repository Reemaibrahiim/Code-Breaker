print "hadeel")
